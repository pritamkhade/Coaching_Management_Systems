<?php

namespace App\Http\Controllers;
use App\Models\Student;
use App\Models\Subject;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

class SubjectController extends Controller
{
    public function index()
    {
        // Get all subjects
        $subjects = Subject::all();
        return response()->json($subjects);
    }

    public function create()
    {
        // Show the form to create a new subject
        // return view('subjects.create');
        return "sucess";
    
    }

    public function store(Request $request)
    {
        $name = $request->input('name');
        $sub_name = $request->input('sub_name');
        
        // Retrieve the student's ID based on the provided name
        $student = DB::table('students')->where('name', $name)->value('student_id');
        
        if ($student) {
            // Insert the subject into the subjects table
            DB::table('subjects')->insert([
                'sub_name' => $sub_name,
                'student_id' => $student
            ]);
    
            return response()->json($request);
        } else {
            return response()->json(['message' => 'Student not found.'], 404);
        }
    }
    

    public function show(Request $request)
    {
        $name = $request->input('name');
        $studentId = $request->input('student_id');
        
        // Retrieve the subjects related to the specified student name and student ID using a join query
        $subjects = DB::table('subjects')
            ->join('students', 'subjects.student_id', '=', 'students.student_id')
            ->where('students.name', $name)
            ->where('students.student_id', $studentId)
            ->select('subjects.*')
            ->get();
    
        if ($subjects->count() > 0) {
            // Subjects found for the specified student name and student ID
            return $subjects;
        } else {
            // Handle case when no subjects found for the specified student name and student ID
            return "No subjects found for the student.";
        }
    }
    
    public function edit(Subject $subject)
    {
        // Show the form to edit a subject
        // return view('subjects.edit', compact('subject'));
        return "sucess";
    }

    public function update(Request $request, Subject $subject)
    {
        // Update the subject in the database
        $subject->update($request->all());
        // Flash a success message to the session
        session()->flash('success', 'Subject updated successfully');
        return redirect()->route('subjects.index');
    }

    public function destroy(Request $request)
    {
        $studentName = $request->input('name');
        $subjectName = $request->input('sub_name');
    
        $deletedRows = DB::table('subjects')
            ->join('students', 'subjects.student_id', '=', 'students.student_id')
            ->where('students.name', $studentName)
            ->where('subjects.sub_name', $subjectName)
            ->delete();
    
        if ($deletedRows > 0) {
            return response()->json(['message' => 'Subject deleted successfully.']);
        } else {
            return response()->json(['message' => 'No subject found for the specified student name and subject.'], 404);
        }
    }
    
    
}
