<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;
use DB;

class StudentController extends Controller
{
    public function index()
    {
        // Get all students
        $students = Student::all();
        // return view('students.index', compact('students'));
        return response()->json($students);
    }

    public function create()
    {
        // Show the form to create a new student
        // return view('students.create');
        return "sucess";
    }

    public function store(Request $request)
    {
        // Store a new student in the database
        // $data = [
        //     'name' => 'John Doe',
        //     'email' => 'johndoe@example.com',
        //     'mobile_no' => 123456755
        // ];
    
        
        $student = Student::create($request->all());
        // return redirect()->route('students.index');
        printf("hello code is working ");
        return response()->json($request);
        

    }

    public function show(Student $student)
    {
        // Show the details of a specific student
        // return view('students.show', compact('student'));
        print_r("hii i am pritam");
        return "sucess";
    }

    public function edit(Student $student)
    {
        // Show the form to edit a student
        // return view('students.edit', compact('student'));
        return "sucess";
    }

    public function update(Request $request, Student $student)
    {
        // Update the student in the database
        // $student->update($request->all());
        // return redirect()->route('students.index');
        $name = $request->input('name');
        $email = $request->input('email');
        DB::update('update students set email = ? where name = ?',[$email,$name]);
        $student->update([ 'email' => $request->input('email')]);
        return response()->json($request);
        // return $request;
    }

    public function destroy(Request $request,Student $student)
    {
        // Delete the student from the database
        $name = $request->input('name');
        // $email = $request->input('email');
        DB::update('delete from students where name = ?',[$name]);
        // $student->delete();
        // return redirect()->route('students.index');
        return " delate ho jay bhai tu abhi";
    }
}
