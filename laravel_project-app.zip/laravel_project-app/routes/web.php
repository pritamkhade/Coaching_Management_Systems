<?php

use Illuminate\Support\Facades\Route;
// use App\Http\Controllers\SubjectController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\SubjectController;
use App\Http\Controllers\UserController;
 
Route::get('/store', [StudentController::class, 'store']);
// Route::post('/store', [StudentController::class, 'show']);
Route::post('/s', [StudentController::class, 'create']);
Route::get('/update', [StudentController::class, 'update']);
Route::get('/delete', [StudentController::class, 'destroy']);
Route::get('/gate_all_Data', [StudentController::class, 'index']);

// ################################################################################
Route::get('/store1', [SubjectController::class, 'store']);
Route::get('/gate_data', [SubjectController::class, 'index']);

Route::get('/delete_subject', [SubjectController::class, 'destroy']);

Route::get('/subjects1', [SubjectController::class, 'show']);







/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/get',StudentController@show);


// Student routes
// Route::resource('students', StudentController::class);

// Route::get('/get', StudentController);

// Subject routes
// Route::resource('subjects', SubjectController::class);
// Route::post('/store',
//     [

//         StudentController::class, 'store'
//     ]
// );
// #####################################################################endregion

// Route::get('/subjects', [SubjectController::class, 'index']);
// Route::post('/store1', [SubjectController::class, 'store']);
// Route::get('/show1', [SubjectController::class, 'show']);
// Route::put('/update1', [SubjectController::class, 'update']);
// Route::delete('/delete', [SubjectController::class, 'destroy']);

// 3#3############################################################################

